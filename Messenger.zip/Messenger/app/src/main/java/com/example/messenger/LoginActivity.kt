package com.example.messenger

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth

class LoginActivity: AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val loginButton = findViewById<Button>(R.id.registerLoginButton)
        val forgotPassword = findViewById<TextView>(R.id.forgot_password)
        val createNewAccount = findViewById<TextView>(R.id.createNewAccount)

        loginButton.setOnClickListener {

            val login_email = findViewById<EditText>(R.id.EmailEditTextLogin).text.toString()
            val login_password = findViewById<EditText>(R.id.PasswordEditTextLogin).text.toString()
            Log.d("LoginActivity", "Login email is: $login_email")
            Log.d("LoginActivity", "Login password is: $login_password")

            //Login details if id is correct
//            val intent = Intent(this,HomeActivity::class.java)
//            startActivity(intent)
            FirebaseAuth.getInstance().createUserWithEmailAndPassword(login_email, login_password)
                .addOnCompleteListener {
                    if (!it.isSuccessful) return@addOnCompleteListener
                    Log.d("Login", "Successfully created user with uid: ${it.result?.user?.uid}")
                }
                .addOnFailureListener {
                    Log.d("Login", "Failed to create user: ${it.message}")
                }
        }
        forgotPassword.setOnClickListener {
            Toast.makeText(this, "I know you forgot your damn password", Toast.LENGTH_SHORT).show()
        }
        createNewAccount.setOnClickListener {
            val intent = Intent(this, RegisterActivity::class.java)
            startActivity(intent)
        }

    }
}