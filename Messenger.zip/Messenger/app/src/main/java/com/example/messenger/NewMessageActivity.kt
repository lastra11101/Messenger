package com.example.messenger

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.messenger.databinding.ActivityNewMessageBinding

class NewMessageActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityNewMessageBinding.inflate(layoutInflater)

        supportActionBar?.title = "Select Users"
    }
}






