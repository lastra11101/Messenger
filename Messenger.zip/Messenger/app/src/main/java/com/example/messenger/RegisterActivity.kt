package com.example.messenger

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.messenger.databinding.ActivityRegisterBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import de.hdodenhof.circleimageview.CircleImageView
import java.util.*

class RegisterActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityRegisterBinding.inflate(layoutInflater)

        // When you click register Button
        binding.registerButton.setOnClickListener {
            preformRegister()
        }
        binding.alreadyHaveAnAccount.setOnClickListener {
            Log.d("RegisterActivity", "Try to go to LoginActivity")

            //launch the Login Activity
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }

        //Select photo
        binding.selectPhotoBtnRegister.setOnClickListener {
            Log.d("RegisterActivity", "Try to select a photo")

            val intent = Intent(Intent.ACTION_PICK)
            intent.type = "image/*"
            startActivityForResult(intent, 0)
        }
    }

    private fun preformRegister() {
        val userName = findViewById<EditText>(R.id.UserEditText).text.toString()
        val email = findViewById<EditText>(R.id.EmailEditText).text.toString()
        val password = findViewById<EditText>(R.id.PasswordEditText).text.toString()
        Log.d("RegisterActivity", "Username is: $userName")
        Log.d("RegisterActivity", "Email is: $email")
        Log.d("RegisterActivity", "Password is: $password")

        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please, enter empty email/password", Toast.LENGTH_SHORT).show()
            return
        }
        // Firebase Authentication to create a user with email and password
        FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener {
                if (!it.isSuccessful) return@addOnCompleteListener
                //else if successful
                Log.d(
                    "RegisterActivity",
                    "Successfully created user with uid: ${it.result?.user?.uid}"
                )
                uploadImageToFirebaseStorage()
            }
            .addOnFailureListener {
                //else if user email is fail
                Log.d("RegisterActivity", "Failed to create user: ${it.message}")
                Toast.makeText(
                    this,
                    "Failed to create user: ${it.message}",
                    Toast.LENGTH_SHORT
                ).show()
            }
    }

    var selectedPhotoUri: Uri? = null

    //To request the photo
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 0 && resultCode == Activity.RESULT_OK && data != null) {
            //Proceed and check what the selected image was..
            Log.d("RegisterActivity", "Photo was selected")

            // This selectedPhotoUri represent of where the location is stored on our device
            selectedPhotoUri = data.data

            val bitmap = MediaStore.Images.Media.getBitmap(contentResolver, selectedPhotoUri)

            val circleImageViewView = findViewById<CircleImageView>(R.id.circleImageView)
            val selectPhotoBtn = findViewById<ImageButton>(R.id.selectPhotoBtnRegister)

            circleImageViewView.setImageBitmap(bitmap)
            selectPhotoBtn.alpha = 0f

//            val bitmapDrawable = BitmapDrawable(bitmap)
//            selectPhotoBtn.setBackgroundDrawable(bitmapDrawable)

        }
    }

    private fun uploadImageToFirebaseStorage() {
        if (selectedPhotoUri == null) return

        val fileName = UUID.randomUUID().toString()
        val ref = FirebaseStorage.getInstance().getReference("/images/$fileName")

        ref.putFile(selectedPhotoUri!!)
            .addOnSuccessListener {
                Log.d("RegisterActivity", "Successfully uploaded images: ${it.metadata?.path}")

                ref.downloadUrl.addOnSuccessListener { it ->
                    Log.d("RegisterActivity", "File location: $it")

                    saveUserToFirebaseDatabase(it.toString())
                }
            }
            .addOnFailureListener {
                Log.d("RegisterActivity", "Image upload failed")
            }
    }

    // Saving the data into the Firebase Database
    private fun saveUserToFirebaseDatabase(profileImageUrl: String) {
        val uid = FirebaseAuth.getInstance().uid ?: ""
        val ref = FirebaseDatabase.getInstance().getReference("/users/$uid")

        val usernameEditTextView = findViewById<EditText>(R.id.UserEditText)
        val user = User(uid, usernameEditTextView.text.toString(), profileImageUrl)

        ref.setValue(user)
            .addOnSuccessListener {
                Log.d("RegisterActivity", "Finally we save user to Firebase Database")

                // After registering the user account it takes us to the new user lists page
                val intent = Intent(this, LatestMessengerActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK.or(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
            }
            .addOnFailureListener {
                Log.d("RegisterActivity", "Failed to save user in Database")
            }

    }
}

// Class to store users information or so called objects
class User(val uid: String, val username: String, val profileImageUrl: String)




















